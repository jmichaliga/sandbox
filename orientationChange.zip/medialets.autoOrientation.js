/**
 * @class medialets.autoOrientation
 * @namespace medialets
 * @requires medialets.js
 * @author ali.hasan@medialets.com
 * @source http://creative.medialytics.com/javascript/medialets.autoOrientation.js
 * @compressed http://creative.medialytics.com/javascript/medialets.autoOrientation.min.js
 * @version 2.0
 */

/**
 * @event m.orientationChange
 * @param {String} event.data.orientation
 */
 
medialets.autoOrientation = function(options) { 
	// data
	// ----- ----- ----- 
	this.o = {
		$target : null,
		format : 'expandable', // expandable | interstitial
		orientation : 'portrait', // portrait | landscape
		delay : 0,
		ignoreFirst : false,
		/* viewport : 
		{
			portrait : { h : 50, w: 100 },
			landscape : { w: 50, h: 100 }
		}
		or 
		viewport : null 
		*/
		viewport : null,
		viewportPattern : 'width=#W,height=#H,initial-scale=1.0,maximum-scale=1.0,user-scalable=no'
	};
	
	var $viewport,
		timeOut = null,
		initialOrientation = null,
		currentOrientation = null;
	
	// functions
	// ----- ----- ----- 
	this.init = function(options) {
		$m.deepCopy(options,this.o);
		this.o.$target = $m(this.o.$target);
		
		if (this.o.viewport !== null && typeof this.o.viewport === 'object') {
			$viewport = $m.find('meta[name=viewport]')[0];
		}
		
		setTimeout(this.trackOrientation.delegate(this), 200);
		
		return this;
	};
	
	this.trackOrientation = function() {
		if (initialOrientation === null) {
			if (this.o.delay > 0) {
				try {
					MMBridge.Orientation.init(this.setOrientationWithDelay.delegate(this));
				}
				catch(err_1) {}
			}
			else {
				try {
					MMBridge.Orientation.init(this.setOrientation.delegate(this));
				}
				catch(err_2) {}					
			}
		
			setTimeout(this.trackOrientation.delegate(this), 200);
		}
	};
	
	this.setOrientationWithDelay = function(angle) {
		try {
			clearTimeout(timeOut);
		} 
		catch (err) {}
		timeOut = setTimeout(function(e) { this.setOrientation(angle); }.delegate(this),this.o.delay);
	};
	
	this.setOrientation = function(angle) { 
		var orientation = parseInt(angle, 10),
			container, className = '';
		 
		if (currentOrientation !== orientation) {
			currentOrientation = orientation;
			if (initialOrientation === null) { 
				initialOrientation = orientation; 
				if (this.o.ignoreFirst) { return; }
			}
			
			// ----------------------------------------
			// portrait orientation
			// ----------------------------------------
			if (this.o.orientation === 'portrait') {
				// start upside down orientation
				if (initialOrientation === 360 || initialOrientation === 180) {
					if (this.o.format === 'expandable') {
						switch (orientation) {
							case 0:
								className = 'portrait';
								break;
							case -90:
								/* If in landscape mode with the screen turned to the right */
								className = 'landscape-right';
								break;
							case 90:
								/* If in landscape mode with the screen turned to the left */
								className = 'landscape-left';
								break;
							case 180:
								/* If in portrait mode with the screen upside down */
								className = 'portrait';
								break;
							case 360:
								/* If in portrait mode with the screen upside down */
								className = 'portrait-180';
								break;
							default:
								className = 'portrait';
						}
					}
					else if (this.o.format === 'interstitial') {
						switch (orientation) {
							case 0:
								className = 'portrait';
								break;
							case -90:
								/* If in landscape mode with the screen turned to the right */
								className = 'landscape-left';
								break;
							case 90:
								/* If in landscape mode with the screen turned to the left */
								className = 'landscape-right';
								break;
							case 180:
								/* If in portrait mode with the screen upside down */
								className = 'portrait-180';
								break;
							case 360:
								/* If in portrait mode with the screen upside down */
								className = 'portrait';
								break;
							default:
								className = 'portrait';
						}					
					}
				}
				// standard orientation
				else {
					switch (orientation) {
						case 0:
							className = 'portrait';
							break;
						case -90:
							/* If in landscape mode with the screen turned to the left */
							className = 'landscape-left';
							break;
						case 90:
							/* If in landscape mode with the screen turned to the right */
							className = 'landscape-right';
							break;
						case 180:
							/* If in portrait mode with the screen upside down */
							className = 'portrait-180';
							break;
						case 360:
							/* If in portrait mode with the screen upside down */
							className = 'portrait-180';
							break;
						default:
							className = 'portrait';
					}
				}// end standard		
			}
			// ----------------------------------------
			// landscape orientation ads, only applies to interstitials
			// ----------------------------------------
			else if (this.o.orientation === 'landscape') {
				// start upside down orientation
                if (initialOrientation === -90 || initialOrientation === 360) {
                    switch (orientation) {
                        case 0:
                            className = 'portrait';
                            break;
                        case -90:
                            className = 'landscape-right';
                            break;
                        case 90:
                            className = 'landscape-left';
                            break;
                        case 180:
                            className = 'portrait-180';
                            break;
                        default:
                            className = 'portrait';
                    }
                }
				// standard orientation
                else {
                    switch (orientation) {
                        case 0:
                            className = 'portrait-180';
                            break;
                        case -90:
                            className = 'landscape-left';
                            break;
                        case 90:
                            className = 'landscape-right';
                            break;
                        case 180:
                            className = 'portrait';
                            break;
                        default:
                            className = 'portrait';
                    }
                }// end standard
			}
			
			if (this.o.$target === null) {
				 container = document;
			}
			else {
				container = this.o.$target;
				container.className = className;
			}
			
			if ($viewport && $viewport.nodeType) {
				if (orientation === 'portrait' || orientation === 'portrait-180') {
					$viewport.content = this.o.viewportPattern.replace(/#H/gi,this.o.portrait.h).replace(/#W/gi,this.o.portrait.w);
				}
				else if (orientation === 'landscape-left' || orientation === 'landscape-right') {
					$viewport.content = this.o.viewportPattern.replace(/#H/gi,this.o.landscape.h).replace(/#W/gi,this.o.landscape.w);
				}
			}					
		
			$m.trigger(container, 'm.orientationChange', { orientation : className });
		}
	};// end set orientation
	
	// start
	this.init(options);
};